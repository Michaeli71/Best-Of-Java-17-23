package b_slides.java21.syntax.jep440_record_patterns;

import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Jep432_RecordPatternsInForExample {
    public static void main(String[] args) {

        record City(String name, int inhabitants) {
        }

        var cities = List.of(new City("Zürich", 400_000),
                new City("Kiel", 265_000),
                new City("Köln", 1_000_000),
                new City("Berlin", 3_500_000));

        for (City city : cities)
        {
            System.out.println(city.name() + " has " +
                               city.inhabitants() + " inhabitants");
        }

        // Works with Java 20
        /*
        for (City(var name, var inhabitants) : cities) {
            System.out.println(name + " has " + inhabitants + " inhabitants");
        }


        var cities2 = Arrays.asList(new City("Zürich", 400_000),
                null,
                new City("Köln", 1_000_000),
                new City("Berlin", 3_500_000));

        for (City(var name, var inhabitants) : cities2) {
            System.out.println(name + " has " + inhabitants + " inhabitants");
        }

        // Extended example

        record Country(String name, Locale locale, City capitalCity) {
        }

        var countries = List.of(new Country("Switzerland", Locale.of("de", "CH"), new City("Bern", 140_000)),
                new Country("Germany", Locale.of("de", "DE"), new City("Berlin", 3_850_000)),
                new Country("France", Locale.of("fr", "FR"), new City("Paris", 11_100_000)));

        for (Country(var name, var locale, City(var cityname, var inhabitants)) : countries) {
            System.out.println("""
                               Country: %s (%s)
                               Capital: %s (%d)
                               Language: %s""".formatted(name, locale.getDisplayCountry(),
                                               cityname, inhabitants, locale.getDisplayLanguage()));
        }
        */
    }
}
