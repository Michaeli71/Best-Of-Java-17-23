package b_slides.java21.api;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.invoke.VarHandle;
import java.lang.reflect.Field;
import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class ReflectionExample 
{
	public static void main(final String[] args) throws ReflectiveOperationException
	{
		accessFieldOldStyle("Java 18 Rocks");
		accessFieldNewStyle("Java 18 Rocks");
	}

	private static void accessFieldOldStyle(final String input) throws ReflectiveOperationException
	{
		var field = String.class.getDeclaredField("value");
		field.setAccessible(true);

		var byteValues = (byte[]) field.get(input);
		System.out.println(Arrays.toString(byteValues));
	}

	private static void accessFieldNewStyle(final String input) throws ReflectiveOperationException
	{
		var lookup = MethodHandles.privateLookupIn(String.class,
				MethodHandles.lookup());
		var handle = lookup.findVarHandle(String.class, "value", byte[].class);

		var byteValues = (byte[]) handle.get(input);
		System.out.println(Arrays.toString(byteValues));
	}
}