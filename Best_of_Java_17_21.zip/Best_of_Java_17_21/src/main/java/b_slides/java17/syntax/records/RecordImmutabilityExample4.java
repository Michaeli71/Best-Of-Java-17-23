package b_slides.java17.syntax.records;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RecordImmutabilityExample4
{
    public static void main(final String[] args)
    {
		record DateRange(LocalDate start, LocalDate end) 
		{
			DateRange
			{
				if (!start.isBefore(end))
					throw new IllegalArgumentException("start >= end");
			}
		}
				
		DateRange range1 = new DateRange(LocalDate.of(1971,1,7), LocalDate.of(1971,2,27));
		System.out.println(range1);
		
		DateRange range2 = new DateRange(LocalDate.of(1971,6,7), LocalDate.of(1971,2,27));
		System.out.println(range2);
    }
}
