package b_slides.java17.api_jvm;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Http2IntroExample
{
    public static void main(final String[] args) throws Exception
    {
        var uri = new URI("https://www.oracle.com/");

        var httpClient = HttpClient.newHttpClient();
        var request = HttpRequest.newBuilder(uri).GET().build();
        var asString = HttpResponse.BodyHandlers.ofString();
        
        var response = httpClient.send(request, asString);

        printResponseInfo(response);
    }

    private static void printResponseInfo(final HttpResponse<String> response)
    {
        final int responseCode = response.statusCode();
        final String responseBody = response.body();
        final HttpHeaders headers = response.headers();
        
        System.out.println("Status:  " + responseCode);
        if (responseCode == 200)
        {
            System.out.println("Body:    " + responseBody.substring(0, 1000));
            System.out.println("Headers: " + headers.map());
        }
    }
}