package solutions.part1;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class Exercise07_instanceof_Records_V3 
{
	// Improvement by applying polymorphism and using the base type in the signature
	public double computeArea(final BaseFigure figure) 
	{
		return figure.calcArea();
	}
	
	
	interface BaseFigure
	{
		double calcArea();
	}
	
	record Square(double sideLength) implements BaseFigure {

		@Override
		public double calcArea() {
			return sideLength * sideLength;
		}
	}

	record Circle(double radius) implements BaseFigure 
	{
		@Override
		public double calcArea() 
		{
			return radius * radius * Math.PI;
		}
	}

	// Rectangle
	record Rectangle(double width, double height) implements BaseFigure {

		@Override
		public double calcArea() {
			return width * height;
		}
	}
}
