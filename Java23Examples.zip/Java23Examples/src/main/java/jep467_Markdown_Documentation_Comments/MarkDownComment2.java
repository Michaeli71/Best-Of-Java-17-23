package jep467_Markdown_Documentation_Comments;

/// **FETT**  \
/// *kursiv*  \
/// _kursiv_  \
/// _**FETT und KURSIV**_\
/// `code-font` \
/// _**`code-font FETT und KURSIV`**_ \
///
/// Mehrzeiliger Sourcecode:
/// ```
 /// public static int max(int a, int b) {
 ///    return (a >= b) ? a : b;
 /// }
 /// ```
public class MarkDownComment2 {

    public static void main(String[] args) {

    }


    /// Returns the greater of two `int` values. That is, the
    /// result is the argument closer to the value of
    /// [Integer#MAX_VALUE]. If the arguments have the same value,
    /// the result is that same value.
    ///
    /// @param   a   an argument.
    /// @param   b   another argument.
    /// @return  the larger of `a` and `b`.
    public static int max(int a, int b) {
        return (a >= b) ? a : b;
    }

    /// _italics_
    /// **BOLD**
    ///
    /// - Bullet Point A
    /// * Bullet Point B
    ///
    /// 1. Numbered Point 1
    /// 1. Numbered Point 2
    ///
    /// Normal Link: [Object#equals(Object)], [System#identityHashCode(Object)]
    ///
    /// @see     java.lang.Object#equals(java.lang.Object)
    /// @see     java.lang.System#identityHashCode(java.lang.Object)
    public static void referencing(String[] args) {
    }

}
