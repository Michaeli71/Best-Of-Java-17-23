package jep476_Module_import_Declarations;

import module java.base;
import module java.desktop;

import java.util.List;

public class InitialModuleImportExample3_V2
{
    public static void main(final String[] args)
    {
        List<String> result = Stream.of("AB", "BC", "CD", "DE").
                              filter(str -> str.contains("C")).
                              toList();
        System.out.println(result);

        IO.print("New Style IO");

        JOptionPane.showMessageDialog(null, "Info");
    }
}
