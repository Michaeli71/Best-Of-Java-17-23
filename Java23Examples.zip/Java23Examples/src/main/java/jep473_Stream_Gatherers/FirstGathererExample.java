package jep473_Stream_Gatherers;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class FirstGathererExample {
    public static void main(final String[] args) {

        // WISH
        /*
        var result = Stream.of("Tim", "Tom", "Jim", "Mike").
                            distinctBy(String::length).      // Hypothetical
                            toList();
        */

        var result = Stream.of("Tim", "Tom", "Jim", "Mike")
                .map(DistinctByLength::new)
                .distinct()
                .map(DistinctByLength::str)
                .toList();

        System.out.println("result: " + result);
    }

    record DistinctByLength(String str) {

        @Override public boolean equals(Object obj) {
            return obj instanceof DistinctByLength(String other)
                    && str.length() == other.length();
        }

        @Override public int hashCode() {
            return str == null ? 0 : Integer.hashCode(str.length());
        }
    }
}
