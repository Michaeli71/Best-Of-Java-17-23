package jep466_Class_File_Api;

import java.io.IOException;
import java.lang.classfile.ClassBuilder;
import java.lang.classfile.ClassFile;
import java.lang.classfile.CodeBuilder;
import java.lang.constant.ClassDesc;
import java.lang.constant.MethodTypeDesc;
import java.nio.file.Path;

import static java.lang.classfile.ClassFile.ACC_PUBLIC;
import static java.lang.classfile.ClassFile.ACC_STATIC;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class HelloWorldClassFileBuilder
{
public static void main(String[] args) throws IOException
{
    ClassFile.of().buildTo(Path.of("HelloWorld.class"),
            ClassDesc.of("HelloWorld"),
                         classBuilder -> createMain(classBuilder));
}

private static ClassBuilder createMain(ClassBuilder classBuilder)
{
    return classBuilder.withMethodBody("main",
                MethodTypeDesc.ofDescriptor("([Ljava/lang/String;)V"),
                ACC_PUBLIC | ACC_STATIC,
                codeBuilder -> createMainBodyCode(codeBuilder));
}

private static CodeBuilder createMainBodyCode(CodeBuilder codeBuilder)
{
    return codeBuilder
            .getstatic(ClassDesc.of("java.lang.System"), "out",
                       ClassDesc.of("java.io.PrintStream"))
            .ldc("Hello World From Class-File API")
            .invokevirtual(ClassDesc.of("java.io.PrintStream"),
                    "println",
                          MethodTypeDesc.ofDescriptor("(Ljava/lang/Object;)V"))
            .return_();
}
}

